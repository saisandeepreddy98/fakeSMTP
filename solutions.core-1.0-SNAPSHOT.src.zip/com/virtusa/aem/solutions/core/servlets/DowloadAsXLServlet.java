/*     */ package com.virtusa.aem.solutions.core.servlets;
/*     */ 
/*     */ import com.adobe.granite.asset.api.Asset;
/*     */ import com.adobe.granite.asset.api.Rendition;
/*     */ import com.virtusa.aem.solutions.core.XLCompareService;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.TreeMap;
/*     */ import javax.servlet.Servlet;
/*     */ import org.apache.poi.ss.usermodel.Cell;
/*     */ import org.apache.poi.ss.usermodel.CellStyle;
/*     */ import org.apache.poi.ss.usermodel.Font;
/*     */ import org.apache.poi.ss.usermodel.IndexedColors;
/*     */ import org.apache.poi.ss.usermodel.Row;
/*     */ import org.apache.poi.ss.usermodel.Sheet;
/*     */ import org.apache.poi.ss.usermodel.Workbook;
/*     */ import org.apache.poi.xssf.usermodel.XSSFWorkbook;
/*     */ import org.apache.sling.api.SlingHttpServletRequest;
/*     */ import org.apache.sling.api.SlingHttpServletResponse;
/*     */ import org.apache.sling.api.resource.Resource;
/*     */ import org.apache.sling.api.resource.ResourceResolver;
/*     */ import org.apache.sling.api.servlets.SlingAllMethodsServlet;
/*     */ import org.osgi.service.component.annotations.Component;
/*     */ import org.osgi.service.component.annotations.Reference;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ @Component(service={Servlet.class}, property={"service.description=RequestHandlerServlet", "sling.servlet.methods=GET", "sling.servlet.paths=/bin/DownloadAsXlServlet"}, immediate=true)
/*     */ public class DowloadAsXLServlet extends SlingAllMethodsServlet
/*     */ {
/*     */   private static final String FIRST_ELEMENT = "FirstElement";
/*     */   private static final String SECOND_ELEMENT = "SecondElement";
/*     */   private static final String ORIGINAL = "original";
/*  46 */   private static final Logger LOG = LoggerFactory.getLogger(DowloadAsXLServlet.class);
/*     */ 
/*     */   @Reference
/*     */   private transient XLCompareService xLCompareService;
/*     */   private transient ResourceResolver resourceResolver;
/*     */ 
/*  54 */   InputStream getStreamFromAEMDam(String xlfilePath) { InputStream inputStream = null;
/*  55 */     Resource resource = this.resourceResolver.getResource(xlfilePath);
/*  56 */     if (null != resource) {
/*  57 */       Asset asset = (Asset)resource.adaptTo(Asset.class);
/*  58 */       if (null != asset) {
/*  59 */         Rendition original = asset.getRendition("original");
/*     */ 
/*  61 */         if (original != null) {
/*  62 */           inputStream = original.getStream();
/*     */         }
/*     */       }
/*     */     }
/*  66 */     return inputStream; }
/*     */ 
/*     */   InputStream getStreamFromFolder(String xlfilePath)
/*     */   {
/*  70 */     FileInputStream excellFile = null;
/*     */     try {
/*  72 */       excellFile = new FileInputStream(xlfilePath);
/*     */     } catch (FileNotFoundException e) {
/*  74 */       LOG.info("Exception in getStreamFromFolder::{}", e.getMessage());
/*     */     }
/*  76 */     return excellFile;
/*     */   }
/*     */ 
/*     */   protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response) throws IOException
/*     */   {
/*  81 */     int firstColumn = 0;
/*  82 */     int secondColumn = 0;
/*  83 */     this.resourceResolver = request.getResourceResolver();
/*  84 */     String xlfilePath1 = request.getParameter("xlFile1");
/*  85 */     String xlfilePath2 = request.getParameter("xlFile2");
/*     */ 
/*  87 */     String xl1coulmnName = request.getParameter("xl1coulmnName");
/*  88 */     String xl2coulmnName = request.getParameter("xl2coulmnName");
/*     */ 
/*  90 */     char alphaXl1 = 'a';
/*  91 */     if (null != xl1coulmnName) {
/*  92 */       xl1coulmnName = xl1coulmnName.toLowerCase();
/*  93 */       alphaXl1 = xl1coulmnName.charAt(0);
/*     */     }
/*     */ 
/*  96 */     firstColumn = alphaXl1 - 'a';
/*     */ 
/*  98 */     char alphaXl2 = 'a';
/*  99 */     if (null != xl2coulmnName) {
/* 100 */       xl2coulmnName = xl2coulmnName.toLowerCase();
/* 101 */       alphaXl2 = xl2coulmnName.charAt(0);
/*     */     }
/*     */ 
/* 104 */     secondColumn = alphaXl2 - 'a';
/*     */ 
/* 106 */     InputStream firstFileInputStream = null;
/* 107 */     InputStream secondFileInputStream = null;
/* 108 */     if (xlfilePath1.contains("/content/dam"))
/* 109 */       firstFileInputStream = getStreamFromAEMDam(xlfilePath1);
/*     */     else {
/* 111 */       firstFileInputStream = getStreamFromFolder(xlfilePath1);
/*     */     }
/*     */ 
/* 114 */     if (xlfilePath2.contains("/content/dam"))
/* 115 */       secondFileInputStream = getStreamFromAEMDam(xlfilePath2);
/*     */     else {
/* 117 */       secondFileInputStream = getStreamFromFolder(xlfilePath2);
/*     */     }
/*     */ 
/* 120 */     Map result = this.xLCompareService.compareTwoXl(firstFileInputStream, secondFileInputStream, firstColumn, secondColumn);
/*     */ 
/* 122 */     File xlfile1 = new File(xlfilePath1);
/* 123 */     File xlfile2 = new File(xlfilePath2);
/*     */ 
/* 125 */     Workbook workbook = new XSSFWorkbook();
/*     */ 
/* 127 */     CellStyle style1 = workbook.createCellStyle();
/* 128 */     Font font = workbook.createFont();
/*     */ 
/* 130 */     font.setColor(IndexedColors.RED.getIndex());
/* 131 */     style1.setFont(font);
/* 132 */     Sheet sheet = workbook.createSheet("compare");
/* 133 */     int rownum = 0;
/* 134 */     Row rowNames = sheet.createRow(rownum++);
/* 135 */     Cell heading = rowNames.createCell(0);
/* 136 */     heading.setCellValue("file Name");
/* 137 */     Cell file1 = rowNames.createCell(1);
/* 138 */     file1.setCellValue(xlfile1.getName());
/* 139 */     Cell file2 = rowNames.createCell(2);
/* 140 */     file2.setCellValue(xlfile2.getName());
/* 141 */     CellStyle cellStyle = file2.getCellStyle();
/* 142 */     cellStyle.setFillBackgroundColor((short)10);
/* 143 */     int cellnum = 0;
/*     */ 
/* 145 */     for (Map.Entry entry : result.entrySet()) {
/* 146 */       cellnum = 0;
/* 147 */       Row row = sheet.createRow(rownum++);
/* 148 */       Cell cell = row.createCell(cellnum++);
/* 149 */       cell.setCellValue((String)entry.getKey());
/* 150 */       Cell cell1 = row.createCell(cellnum++);
/* 151 */       if (((Integer)((TreeMap)entry.getValue()).get("FirstElement")).intValue() == 1) {
/* 152 */         cell1.setCellValue("yes");
/*     */       } else {
/* 154 */         cell1.setCellValue("no");
/* 155 */         cell1.setCellStyle(style1);
/*     */       }
/*     */ 
/* 158 */       Cell cell2 = row.createCell(cellnum);
/*     */ 
/* 160 */       if (((Integer)((TreeMap)entry.getValue()).get("SecondElement")).intValue() == 1) {
/* 161 */         cell2.setCellValue("yes");
/*     */       }
/*     */       else {
/* 164 */         cell2.setCellValue("no");
/* 165 */         cell2.setCellStyle(style1);
/*     */       }
/*     */     }
/*     */     try
/*     */     {
/* 170 */       response.setContentType("application/vnd.ms-excel");
/* 171 */       response.setHeader("Content-Disposition", "attachment; filename=CompareTwoXL.xlsx");
/* 172 */       workbook.write(response.getOutputStream());
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 176 */       LOG.info("exception in dowloading the file{}", e.getMessage());
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\work\solutions.ui.apps-1.0-SNAPSHOT\jcr_root\apps\solutions\install\solutions.core-1.0-SNAPSHOT.jar
 * Qualified Name:     com.virtusa.aem.solutions.core.servlets.DowloadAsXLServlet
 * JD-Core Version:    0.6.2
 */