package com.virtusa.aem.solutions.core;

import java.io.InputStream;
import java.util.Map;
import java.util.TreeMap;

public abstract interface XLCompareService
{
  public abstract Map<String, TreeMap<String, Integer>> compareTwoXl(InputStream paramInputStream1, InputStream paramInputStream2, int paramInt1, int paramInt2);
}

/* Location:           E:\work\solutions.ui.apps-1.0-SNAPSHOT\jcr_root\apps\solutions\install\solutions.core-1.0-SNAPSHOT.jar
 * Qualified Name:     com.virtusa.aem.solutions.core.XLCompareService
 * JD-Core Version:    0.6.2
 */