/*    */ package com.virtusa.aem.solutions.core;
/*    */ 
/*    */ import com.day.cq.search.PredicateGroup;
/*    */ import com.day.cq.search.Query;
/*    */ import com.day.cq.search.QueryBuilder;
/*    */ import com.day.cq.search.result.Hit;
/*    */ import com.day.cq.search.result.SearchResult;
/*    */ import java.util.ArrayList;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import javax.jcr.Node;
/*    */ import javax.jcr.RepositoryException;
/*    */ import javax.jcr.Session;
/*    */ import org.apache.sling.api.resource.Resource;
/*    */ import org.apache.sling.api.resource.ResourceResolver;
/*    */ import org.osgi.service.component.annotations.Component;
/*    */ import org.osgi.service.component.annotations.ConfigurationPolicy;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ @Component(service={AssetImagesListService.class}, configurationPolicy=ConfigurationPolicy.OPTIONAL)
/*    */ public class AssetImagesListServiceImpl
/*    */   implements AssetImagesListService
/*    */ {
/* 35 */   private static final Logger LOG = LoggerFactory.getLogger(AssetImagesListServiceImpl.class);
/*    */ 
/*    */   public Map<String, String> generateXL(Resource resource, String path)
/*    */   {
/* 39 */     Map result = new HashMap();
/*    */ 
/* 41 */     String message = "";
/*    */ 
/* 43 */     ResourceResolver resourceResolver = resource.getResourceResolver();
/*    */ 
/* 45 */     Resource currentPageResource = resourceResolver.getResource(path);
/*    */ 
/* 47 */     QueryBuilder queryBuilder = (QueryBuilder)resourceResolver.adaptTo(QueryBuilder.class);
/* 48 */     Session session = (Session)resourceResolver.adaptTo(Session.class);
/* 49 */     ArrayList data = new ArrayList();
/* 50 */     if (currentPageResource != null)
/*    */     {
/* 52 */       Map predicateMap = new HashMap();
/* 53 */       predicateMap.put("path", path);
/* 54 */       predicateMap.put("type", "dam:Asset");
/* 55 */       predicateMap.put("p.limit", "-1");
/*    */ 
/* 57 */       Query query = queryBuilder.createQuery(PredicateGroup.create(predicateMap), session);
/* 58 */       SearchResult search = query.getResult();
/* 59 */       data.add(new String[] { "AssetName" });
/* 60 */       for (Hit hit : search.getHits()) {
/*    */         try
/*    */         {
/* 63 */           Node node = hit.getNode();
/*    */ 
/* 65 */           result.put(node.getPath(), node.getName());
/*    */ 
/* 67 */           data.add(new Object[] { node.getName() });
/*    */         } catch (RepositoryException e) {
/* 69 */           LOG.info("came into exception E{}", e.getMessage());
/*    */         }
/*    */       }
/*    */ 
/*    */     }
/*    */ 
/* 75 */     return result;
/*    */   }
/*    */ }

/* Location:           E:\work\solutions.ui.apps-1.0-SNAPSHOT\jcr_root\apps\solutions\install\solutions.core-1.0-SNAPSHOT.jar
 * Qualified Name:     com.virtusa.aem.solutions.core.AssetImagesListServiceImpl
 * JD-Core Version:    0.6.2
 */