/*     */ package com.virtusa.aem.solutions.core;
/*     */ 
/*     */ import java.io.InputStream;
/*     */ import java.util.Map;
/*     */ import java.util.TreeMap;
/*     */ import org.apache.poi.xssf.usermodel.XSSFCell;
/*     */ import org.apache.poi.xssf.usermodel.XSSFRow;
/*     */ import org.apache.poi.xssf.usermodel.XSSFSheet;
/*     */ import org.apache.poi.xssf.usermodel.XSSFWorkbook;
/*     */ import org.osgi.service.component.annotations.Component;
/*     */ import org.osgi.service.component.annotations.ConfigurationPolicy;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ @Component(service={XLCompareService.class}, configurationPolicy=ConfigurationPolicy.OPTIONAL)
/*     */ public class XLCompareServiceImpl
/*     */   implements XLCompareService
/*     */ {
/*  20 */   private static final Logger LOG = LoggerFactory.getLogger(XLCompareServiceImpl.class);
/*     */   private static final String FIRST_ELEMENT = "FirstElement";
/*     */   private static final String SECOND_ELEMENT = "SecondElement";
/*  24 */   private int firstColumn = 0;
/*  25 */   private int secondColumn = 0;
/*     */ 
/*     */   public Map<String, TreeMap<String, Integer>> compareTwoXl(InputStream inputStream1, InputStream inputStream2, int file1CoulmnNumber, int file2CoulmnNumber)
/*     */   {
/*  29 */     TreeMap result = new TreeMap();
/*     */     try
/*     */     {
/*  32 */       this.firstColumn = file1CoulmnNumber;
/*     */ 
/*  34 */       this.secondColumn = file2CoulmnNumber;
/*  35 */       XSSFWorkbook workbook1 = new XSSFWorkbook(inputStream1);
/*  36 */       XSSFWorkbook workbook2 = new XSSFWorkbook(inputStream2);
/*     */ 
/*  38 */       XSSFSheet sheet1 = workbook1.getSheetAt(0);
/*  39 */       XSSFSheet sheet2 = workbook2.getSheetAt(0);
/*     */ 
/*  41 */       compareFirstXLWithSecond(sheet1, sheet2, result);
/*  42 */       compareSecondXLWithfirst(sheet1, sheet2, result);
/*  43 */       return result;
/*     */     } catch (Exception e) {
/*  45 */       LOG.info("Came Into Exception::{}", e.getMessage());
/*     */     }
/*     */ 
/*  48 */     return result;
/*     */   }
/*     */ 
/*     */   private TreeMap<String, Integer> compareOneCellOfFirstXLWithSecond(TreeMap<String, Integer> subResult, int lastRowNum2, XSSFSheet sheet2, String stringCellValue)
/*     */   {
/*  54 */     for (int j = 0; j <= lastRowNum2; j++)
/*     */     {
/*  56 */       XSSFRow row2 = sheet2.getRow(j);
/*  57 */       if (row2 != null)
/*     */       {
/*  59 */         XSSFCell cell2 = row2.getCell(this.secondColumn);
/*  60 */         if (cell2 != null) {
/*  61 */           String stringCellValue2 = cell2.getStringCellValue();
/*  62 */           if (stringCellValue.equals(stringCellValue2)) {
/*  63 */             subResult.put("SecondElement", Integer.valueOf(1));
/*  64 */             break;
/*     */           }
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/*  72 */     return subResult;
/*     */   }
/*     */ 
/*     */   private TreeMap<String, TreeMap<String, Integer>> compareFirstXLWithSecond(XSSFSheet sheet1, XSSFSheet sheet2, TreeMap<String, TreeMap<String, Integer>> result)
/*     */   {
/*  77 */     int lastRowNum1 = sheet1.getLastRowNum();
/*  78 */     int lastRowNum2 = sheet2.getLastRowNum();
/*  79 */     for (int i = 0; i <= lastRowNum1; i++) {
/*  80 */       TreeMap subResult = new TreeMap();
/*  81 */       XSSFRow row = sheet1.getRow(i);
/*  82 */       if (row != null) {
/*  83 */         XSSFCell cell = row.getCell(this.firstColumn);
/*  84 */         if (cell != null) {
/*  85 */           String stringCellValue = cell.getStringCellValue();
/*  86 */           subResult.put("FirstElement", Integer.valueOf(1));
/*  87 */           compareOneCellOfFirstXLWithSecond(subResult, lastRowNum2, sheet2, stringCellValue);
/*  88 */           if (!subResult.containsKey("SecondElement")) {
/*  89 */             subResult.put("SecondElement", Integer.valueOf(0));
/*     */           }
/*  91 */           result.put(stringCellValue, subResult);
/*     */         }
/*     */       }
/*     */     }
/*  95 */     return result;
/*     */   }
/*     */ 
/*     */   private void compareOneCellOfSecondXLWithFirst(TreeMap<String, Integer> subResult, int lastRowNum1, XSSFSheet sheet1, String stringCellValue)
/*     */   {
/* 100 */     for (int j = 0; j <= lastRowNum1; j++)
/*     */     {
/* 102 */       XSSFRow row2 = sheet1.getRow(j);
/* 103 */       if (row2 != null) {
/* 104 */         XSSFCell cell2 = row2.getCell(this.secondColumn);
/* 105 */         if (cell2 != null) {
/* 106 */           String stringCellValue2 = cell2.getStringCellValue();
/* 107 */           if (stringCellValue.equals(stringCellValue2)) {
/* 108 */             subResult.put("FirstElement", Integer.valueOf(1));
/* 109 */             break;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private TreeMap<String, TreeMap<String, Integer>> compareSecondXLWithfirst(XSSFSheet sheet1, XSSFSheet sheet2, TreeMap<String, TreeMap<String, Integer>> result)
/*     */   {
/* 119 */     int lastRowNum1 = sheet1.getLastRowNum();
/* 120 */     int lastRowNum2 = sheet2.getLastRowNum();
/* 121 */     for (int i = 0; i <= lastRowNum2; i++) {
/* 122 */       TreeMap subResult = new TreeMap();
/* 123 */       XSSFRow row = sheet2.getRow(i);
/* 124 */       if (row != null) {
/* 125 */         XSSFCell cell = row.getCell(this.secondColumn);
/*     */ 
/* 127 */         if (cell != null) {
/* 128 */           String stringCellValue = cell.getStringCellValue();
/* 129 */           if (!result.containsKey(stringCellValue)) {
/* 130 */             subResult.put("SecondElement", Integer.valueOf(1));
/* 131 */             compareOneCellOfSecondXLWithFirst(subResult, lastRowNum1, sheet1, stringCellValue);
/* 132 */             if (!subResult.containsKey("FirstElement")) {
/* 133 */               subResult.put("FirstElement", Integer.valueOf(0));
/*     */             }
/* 135 */             result.put(stringCellValue, subResult);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 141 */     return result;
/*     */   }
/*     */ }

/* Location:           E:\work\solutions.ui.apps-1.0-SNAPSHOT\jcr_root\apps\solutions\install\solutions.core-1.0-SNAPSHOT.jar
 * Qualified Name:     com.virtusa.aem.solutions.core.XLCompareServiceImpl
 * JD-Core Version:    0.6.2
 */