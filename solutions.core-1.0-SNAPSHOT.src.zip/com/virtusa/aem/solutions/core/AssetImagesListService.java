package com.virtusa.aem.solutions.core;

import java.util.Map;
import org.apache.sling.api.resource.Resource;

public abstract interface AssetImagesListService
{
  public abstract Map<String, String> generateXL(Resource paramResource, String paramString);
}

/* Location:           E:\work\solutions.ui.apps-1.0-SNAPSHOT\jcr_root\apps\solutions\install\solutions.core-1.0-SNAPSHOT.jar
 * Qualified Name:     com.virtusa.aem.solutions.core.AssetImagesListService
 * JD-Core Version:    0.6.2
 */