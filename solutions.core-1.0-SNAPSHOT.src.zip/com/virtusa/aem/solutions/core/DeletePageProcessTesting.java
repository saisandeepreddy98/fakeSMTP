/*    */ package com.virtusa.aem.solutions.core;
/*    */ 
/*    */ import com.day.cq.workflow.WorkflowException;
/*    */ import com.day.cq.workflow.WorkflowSession;
/*    */ import com.day.cq.workflow.exec.WorkItem;
/*    */ import com.day.cq.workflow.exec.WorkflowData;
/*    */ import com.day.cq.workflow.exec.WorkflowProcess;
/*    */ import com.day.cq.workflow.metadata.MetaDataMap;
/*    */ import java.util.Collections;
/*    */ import javax.jcr.Node;
/*    */ import javax.jcr.RepositoryException;
/*    */ import javax.jcr.Session;
/*    */ import org.apache.sling.api.resource.LoginException;
/*    */ import org.apache.sling.api.resource.Resource;
/*    */ import org.apache.sling.api.resource.ResourceResolver;
/*    */ import org.apache.sling.api.resource.ResourceResolverFactory;
/*    */ import org.osgi.service.component.annotations.Component;
/*    */ import org.osgi.service.component.annotations.Reference;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ @Component(service={WorkflowProcess.class}, property={"process.label=Delete Page testing"})
/*    */ public class DeletePageProcessTesting
/*    */   implements WorkflowProcess
/*    */ {
/*    */ 
/*    */   @Reference
/*    */   protected ResourceResolverFactory resourceResolverFactory;
/* 31 */   private static final Logger log = LoggerFactory.getLogger(DeletePageProcessTesting.class);
/*    */   private static final String TYPE_JCR_PATH = "JCR_PATH";
/*    */ 
/*    */   public void execute(WorkItem workItem, WorkflowSession workflowSession, MetaDataMap metaDataMap)
/*    */     throws WorkflowException
/*    */   {
/*    */     try
/*    */     {
/* 46 */       log.info("came into our delete page process exceute method");
/* 47 */       Session session = workflowSession.getSession();
/*    */ 
/* 49 */       ResourceResolver resolver = this.resourceResolverFactory.getResourceResolver(Collections.singletonMap("user.jcr.session", session));
/*    */ 
/* 52 */       WorkflowData data = workItem.getWorkflowData();
/* 53 */       String path = null;
/* 54 */       String type = data.getPayloadType();
/* 55 */       if ((type.equals("JCR_PATH")) && (data.getPayload() != null)) {
/* 56 */         String payloadData = (String)data.getPayload();
/* 57 */         if (session.itemExists(payloadData)) {
/* 58 */           path = payloadData;
/*    */         }
/*    */       }
/*    */ 
/* 62 */       if (path == null) {
/* 63 */         throw new WorkflowException("No path was given for the workflow");
/*    */       }
/*    */ 
/* 67 */       Resource resource = resolver.getResource(path);
/*    */ 
/* 70 */       Node node = (Node)resource.adaptTo(Node.class);
/* 71 */       if (session.nodeExists(node.getPath())) {
/* 72 */         node.remove();
/*    */       }
/* 74 */       session.save(); } catch (RepositoryException e) {
/* 75 */       e = 
/* 79 */         e;
/*    */ 
/* 76 */       throw new WorkflowException(e); } catch (LoginException e) {
/* 77 */       e = e;
/*    */ 
/* 78 */       throw new WorkflowException(e); } finally {
/*    */     }
/*    */   }
/*    */ 
/* 82 */   protected void bindResourceResolverFactory(ResourceResolverFactory paramResourceResolverFactory) { this.resourceResolverFactory = paramResourceResolverFactory; }
/*    */ 
/*    */   protected void unbindResourceResolverFactory(ResourceResolverFactory paramResourceResolverFactory) {
/* 85 */     if (this.resourceResolverFactory == paramResourceResolverFactory)
/* 86 */       this.resourceResolverFactory = null;
/*    */   }
/*    */ }

/* Location:           E:\work\solutions.ui.apps-1.0-SNAPSHOT\jcr_root\apps\solutions\install\solutions.core-1.0-SNAPSHOT.jar
 * Qualified Name:     com.virtusa.aem.solutions.core.DeletePageProcessTesting
 * JD-Core Version:    0.6.2
 */