/*     */ package com.virtusa.aem.solutions.core.models;
/*     */ 
/*     */ import com.adobe.granite.asset.api.Asset;
/*     */ import com.adobe.granite.asset.api.Rendition;
/*     */ import com.virtusa.aem.solutions.core.XLCompareService;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.InputStream;
/*     */ import java.util.Map;
/*     */ import java.util.TreeMap;
/*     */ import javax.annotation.PostConstruct;
/*     */ import javax.inject.Inject;
/*     */ import javax.inject.Named;
/*     */ import org.apache.sling.api.resource.Resource;
/*     */ import org.apache.sling.api.resource.ResourceResolver;
/*     */ import org.apache.sling.models.annotations.Default;
/*     */ import org.apache.sling.models.annotations.Model;
/*     */ import org.apache.sling.models.annotations.injectorspecific.Self;
/*     */ import org.apache.sling.settings.SlingSettingsService;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ @Model(adaptables={Resource.class})
/*     */ public class XlCompareModel
/*     */ {
/*  29 */   private static final Logger LOG = LoggerFactory.getLogger(XlCompareModel.class);
/*     */ 
/*     */   @Self
/*     */   private Resource resource;
/*     */ 
/*     */   @Inject
/*     */   private SlingSettingsService settings;
/*     */ 
/*     */   @Inject
/*     */   @Named("xl1FilePath")
/*     */   @Default(values={"c:\\"})
/*     */   protected String xl1FilePath;
/*     */ 
/*     */   @Inject
/*     */   @Named("xl1coulmnName")
/*     */   @Default(values={"a"})
/*     */   protected String xl1coulmnName;
/*     */ 
/*     */   @Inject
/*     */   @Named("xl2coulmnName")
/*     */   @Default(values={"a"})
/*     */   protected String xl2coulmnName;
/*     */ 
/*     */   @Inject
/*     */   @Named("xl2FilePath")
/*     */   @Default(values={"C:\\"})
/*     */   protected String xl2FilePath;
/*     */ 
/*     */   @Inject
/*     */   private XLCompareService xlLCompareService;
/*     */   private static final String ORIGINAL = "original";
/*     */   private String message;
/*     */   private Map<String, TreeMap<String, Integer>> mapServiceResult;
/*     */ 
/*  68 */   @PostConstruct
/*     */   protected void init() { InputStream firstFileInputStream = null;
/*  69 */     InputStream secondFileInputStream = null;
/*  70 */     if (this.xl1FilePath.contains("/content/dam"))
/*  71 */       firstFileInputStream = getStreamFromAEMDam(this.xl1FilePath);
/*     */     else {
/*  73 */       firstFileInputStream = getStreamFromFolder(this.xl1FilePath);
/*     */     }
/*     */ 
/*  76 */     if (this.xl2FilePath.contains("/content/dam"))
/*  77 */       secondFileInputStream = getStreamFromAEMDam(this.xl2FilePath);
/*     */     else
/*  79 */       secondFileInputStream = getStreamFromFolder(this.xl2FilePath);
/*     */     try
/*     */     {
/*  82 */       char alphaXl1 = 'a';
/*  83 */       if (null != this.xl1coulmnName) {
/*  84 */         this.xl1coulmnName = this.xl1coulmnName.toLowerCase();
/*  85 */         alphaXl1 = this.xl1coulmnName.charAt(0);
/*     */       }
/*     */ 
/*  88 */       int xl1Numbers = alphaXl1 - 'a';
/*     */ 
/*  90 */       char alphaXl2 = 'a';
/*  91 */       if (null != this.xl2coulmnName) {
/*  92 */         this.xl2coulmnName = this.xl2coulmnName.toLowerCase();
/*  93 */         alphaXl2 = this.xl2coulmnName.charAt(0);
/*     */       }
/*     */ 
/*  96 */       int xl2Numbers = alphaXl2 - 'a';
/*     */ 
/*  98 */       this.mapServiceResult = this.xlLCompareService.compareTwoXl(firstFileInputStream, secondFileInputStream, xl1Numbers, xl2Numbers);
/*     */ 
/* 100 */       LOG.info("mapServiceResult:::::{}", this.mapServiceResult);
/*     */     } catch (Exception E) {
/* 102 */       this.message = E.getMessage();
/*     */     } }
/*     */ 
/*     */   public Map<String, TreeMap<String, Integer>> getResultMap()
/*     */   {
/* 107 */     return this.mapServiceResult;
/*     */   }
/*     */ 
/*     */   InputStream getStreamFromAEMDam(String xlfilePath) {
/* 111 */     InputStream inputStream = null;
/* 112 */     ResourceResolver resourceResolver = this.resource.getResourceResolver();
/* 113 */     Resource resourceAsset = resourceResolver.getResource(xlfilePath);
/* 114 */     if (null != resourceAsset) {
/* 115 */       Asset asset = (Asset)resourceAsset.adaptTo(Asset.class);
/* 116 */       if (null != asset) {
/* 117 */         Rendition original = asset.getRendition("original");
/*     */ 
/* 119 */         if (original != null) {
/* 120 */           inputStream = original.getStream();
/*     */         }
/*     */       }
/*     */     }
/* 124 */     return inputStream;
/*     */   }
/*     */ 
/*     */   InputStream getStreamFromFolder(String xlfilePath) {
/* 128 */     FileInputStream excellFile = null;
/*     */     try {
/* 130 */       excellFile = new FileInputStream(xlfilePath);
/*     */     } catch (FileNotFoundException e) {
/* 132 */       LOG.info("Exception in getStreamFromFolder::{}", e.getMessage());
/*     */     }
/* 134 */     return excellFile;
/*     */   }
/*     */ 
/*     */   public String getMessage() {
/* 138 */     return this.message;
/*     */   }
/*     */ }

/* Location:           E:\work\solutions.ui.apps-1.0-SNAPSHOT\jcr_root\apps\solutions\install\solutions.core-1.0-SNAPSHOT.jar
 * Qualified Name:     com.virtusa.aem.solutions.core.models.XlCompareModel
 * JD-Core Version:    0.6.2
 */