/*    */ package com.virtusa.aem.solutions.core.models;
/*    */ 
/*    */ import com.virtusa.aem.solutions.core.AssetImagesListService;
/*    */ import java.util.Map;
/*    */ import javax.annotation.PostConstruct;
/*    */ import javax.inject.Inject;
/*    */ import javax.inject.Named;
/*    */ import org.apache.sling.api.resource.Resource;
/*    */ import org.apache.sling.models.annotations.Default;
/*    */ import org.apache.sling.models.annotations.Model;
/*    */ import org.apache.sling.models.annotations.injectorspecific.Self;
/*    */ import org.apache.sling.settings.SlingSettingsService;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ @Model(adaptables={Resource.class})
/*    */ public class AssetImagesListModel
/*    */ {
/* 23 */   private static final Logger LOG = LoggerFactory.getLogger(AssetImagesListModel.class);
/*    */ 
/*    */   @Self
/*    */   private Resource resource;
/*    */ 
/*    */   @Inject
/*    */   private SlingSettingsService settings;
/*    */ 
/*    */   @Inject
/*    */   @Named("queryPath")
/*    */   @Default(values={"/content/dam"})
/*    */   protected String queryPath;
/*    */ 
/*    */   @Inject
/*    */   private AssetImagesListService assetImagesListService;
/*    */   private String message;
/*    */   private Map<String, String> mapServiceResult;
/*    */ 
/* 46 */   @PostConstruct
/*    */   protected void init() { this.mapServiceResult = this.assetImagesListService.generateXL(this.resource, this.queryPath);
/* 47 */     LOG.info("mapServiceResult xlDam:::::{}", this.mapServiceResult); }
/*    */ 
/*    */   public Map<String, String> getResultMap()
/*    */   {
/* 51 */     return this.mapServiceResult;
/*    */   }
/*    */ 
/*    */   public String getMessage() {
/* 55 */     return this.message;
/*    */   }
/*    */ }

/* Location:           E:\work\solutions.ui.apps-1.0-SNAPSHOT\jcr_root\apps\solutions\install\solutions.core-1.0-SNAPSHOT.jar
 * Qualified Name:     com.virtusa.aem.solutions.core.models.AssetImagesListModel
 * JD-Core Version:    0.6.2
 */