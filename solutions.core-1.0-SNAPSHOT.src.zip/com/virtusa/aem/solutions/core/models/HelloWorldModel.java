/*    */ package com.virtusa.aem.solutions.core.models;
/*    */ 
/*    */ import javax.annotation.PostConstruct;
/*    */ import javax.inject.Inject;
/*    */ import javax.inject.Named;
/*    */ import org.apache.sling.api.resource.Resource;
/*    */ import org.apache.sling.models.annotations.Default;
/*    */ import org.apache.sling.models.annotations.Model;
/*    */ import org.apache.sling.settings.SlingSettingsService;
/*    */ 
/*    */ @Model(adaptables={Resource.class})
/*    */ public class HelloWorldModel
/*    */ {
/*    */ 
/*    */   @Inject
/*    */   private SlingSettingsService settings;
/*    */ 
/*    */   @Inject
/*    */   @Named("sling:resourceType")
/*    */   @Default(values={"No resourceType"})
/*    */   protected String resourceType;
/*    */   private String message;
/*    */ 
/*    */   @PostConstruct
/*    */   protected void init()
/*    */   {
/* 26 */     this.message = "\tHello World!\n";
/* 27 */     this.message = (this.message + "\tThis is instance: " + this.settings.getSlingId() + "\n");
/* 28 */     this.message = (this.message + "\tResource type is: " + this.resourceType + "\n");
/*    */   }
/*    */ 
/*    */   public String getMessage() {
/* 32 */     return this.message;
/*    */   }
/*    */ }

/* Location:           E:\work\solutions.ui.apps-1.0-SNAPSHOT\jcr_root\apps\solutions\install\solutions.core-1.0-SNAPSHOT.jar
 * Qualified Name:     com.virtusa.aem.solutions.core.models.HelloWorldModel
 * JD-Core Version:    0.6.2
 */